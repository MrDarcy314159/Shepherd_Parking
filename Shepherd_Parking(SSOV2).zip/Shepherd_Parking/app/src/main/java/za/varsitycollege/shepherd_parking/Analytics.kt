package za.varsitycollege.shepherd_parking

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyticsPage(navController: NavController) {
    var morningCapacity by remember { mutableStateOf(0.7f) }
    var afternoonCapacity by remember { mutableStateOf(0.84f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppColors.MintGreen)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Title Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),  // Adjusted spacing between title and content card
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SHEPHERD PARKING",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppColors.DarkGray
                            )
                            Text(
                                text = "Analytics",
                                fontSize = 18.sp,
                                color = AppColors.DarkGray
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.sheep), // Replace with your actual resource
                            contentDescription = "Sheep Logo",
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(AppColors.MintGreen)
                        )
                    }
                }
            }

            // Main Content Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),  // This ensures the card takes up the remaining vertical space
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 24.dp),  // Adjusted padding for better layout
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp) // Consistent spacing between elements
                ) {
                    // Projected Capacity for Tomorrow (Morning)
                    Text(
                        text = "Projected Capacity for Tomorrow (Morning)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppColors.DarkGray
                    )
                    Text(
                        text = "${(morningCapacity * 100).toInt()}% Full",
                        fontSize = 16.sp,
                        color = AppColors.DarkGray
                    )
                    Slider(
                        value = morningCapacity,
                        onValueChange = { morningCapacity = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = AppColors.DarkGray,
                            activeTrackColor = AppColors.DarkGray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Projected Capacity for Tomorrow (Afternoon)
                    Text(
                        text = "Projected Capacity for Tomorrow (Afternoon)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppColors.DarkGray
                    )
                    Text(
                        text = "${(afternoonCapacity * 100).toInt()}% Full",
                        fontSize = 16.sp,
                        color = AppColors.DarkGray
                    )
                    Slider(
                        value = afternoonCapacity,
                        onValueChange = { afternoonCapacity = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = AppColors.DarkGray,
                            activeTrackColor = AppColors.DarkGray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Day-wise Analytics Chart (Placeholder for an actual chart)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp),  // Adjusted height for the chart card
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Day:",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppColors.DarkGray
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            // Placeholder for a chart
                            Image(
                                painter = painterResource(id = R.drawable.monitor), // Replace with your actual resource
                                contentDescription = "Chart",
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }
        // Varsity College logo at the bottom
        Image(
            painter = painterResource(id = R.drawable.varsity_college_icon),
            contentDescription = "Varsity College Logo",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
                .height(50.dp)

        )
    }
}

@Preview(showBackground = true)
@Composable
fun AnalyticsPagePreview() {
    val navController = rememberNavController()
    MaterialTheme {
        AnalyticsPage(navController)
    }
}