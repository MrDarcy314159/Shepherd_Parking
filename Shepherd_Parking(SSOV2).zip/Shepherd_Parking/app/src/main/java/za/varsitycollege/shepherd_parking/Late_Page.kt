package za.varsitycollege.shepherd_parking

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Late_Page(navController: NavController) {
    var studentNumber by remember { mutableStateOf("ST10000001") }
    var selectedLecturer by remember { mutableStateOf("Select Lecturer") }
    var selectedReason by remember { mutableStateOf("Select Reason") }
    var extraInformation by remember { mutableStateOf("") }
    var lecturerDropdownExpanded by remember { mutableStateOf(false) }
    var reasonDropdownExpanded by remember { mutableStateOf(false) }
    var showSuccessDialog by remember { mutableStateOf(false) }

    val firestore: FirebaseFirestore = Firebase.firestore

    // Dropdown options for Lecturer and Reason
    val lecturers = listOf("Lecturer 1", "Lecturer 2", "Lecturer 3")
    val reasons = listOf("Traffic", "Accident", "Other")

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AppColors.MintGreen)
            .padding(16.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SHEPHERD PARKING",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = AppColors.DarkGray
                            )
                            Text(
                                text = "Late",
                                fontSize = 18.sp,
                                color = AppColors.DarkGray
                            )
                        }
                        Image(
                            painter = painterResource(id = R.drawable.sheep),
                            contentDescription = "Sheep Logo",
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(AppColors.MintGreen)
                        )
                    }
                }
            }
            // Main Content Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.robot_icon),
                        contentDescription = "Robot Icon",
                        modifier = Modifier.size(80.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Add Lecturer Button
                    OutlinedButton(
                        onClick = { navController.navigate("lecturer_details") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),  // Space between button and dropdown
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AppColors.DarkGray)
                    ) {
                        Text("Add Lecturer")
                    }

                    // Lecturer Dropdown
                    ExposedDropdownMenuBox(
                        expanded = lecturerDropdownExpanded,
                        onExpandedChange = { lecturerDropdownExpanded = !lecturerDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedLecturer,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Lecturer") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = lecturerDropdownExpanded)
                            },
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                                focusedBorderColor = AppColors.MintGreen,
                                unfocusedBorderColor = AppColors.DarkGray
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = lecturerDropdownExpanded,
                            onDismissRequest = { lecturerDropdownExpanded = false }
                        ) {
                            lecturers.forEach { lecturer ->
                                DropdownMenuItem(
                                    text = { Text(lecturer) },
                                    onClick = {
                                        selectedLecturer = lecturer
                                        lecturerDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Reason Dropdown
                    ExposedDropdownMenuBox(
                        expanded = reasonDropdownExpanded,
                        onExpandedChange = { reasonDropdownExpanded = !reasonDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedReason,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Reason") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = reasonDropdownExpanded)
                            },
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(
                                focusedBorderColor = AppColors.MintGreen,
                                unfocusedBorderColor = AppColors.DarkGray
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = reasonDropdownExpanded,
                            onDismissRequest = { reasonDropdownExpanded = false }
                        ) {
                            reasons.forEach { reason ->
                                DropdownMenuItem(
                                    text = { Text(reason) },
                                    onClick = {
                                        selectedReason = reason
                                        reasonDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Extra Information TextBox
                    OutlinedTextField(
                        value = extraInformation,
                        onValueChange = { extraInformation = it },
                        label = { Text("Extra Information") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(75.dp),
                        colors = TextFieldDefaults.outlinedTextFieldColors(
                            focusedBorderColor = AppColors.MintGreen,
                            unfocusedBorderColor = AppColors.DarkGray
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Start
                    ) {
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Button(
                                onClick = {
                                    // Clear the fields
                                    selectedLecturer = "Select Lecturer"
                                    selectedReason = "Select Reason"
                                    extraInformation = ""
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = AppColors.DarkGray
                                ),
                                border = BorderStroke(2.dp, AppColors.DarkGray)
                            ) {
                                Text("Clear")
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Button(
                                onClick = {
                                    if (selectedLecturer != "Select Lecturer" &&
                                        selectedReason != "Select Reason" &&
                                        extraInformation.isNotBlank()
                                    ) {
                                        // Save data to Firestore
                                        val lateData = hashMapOf(
                                            "studentNumber" to studentNumber,
                                            "lecturer" to selectedLecturer,
                                            "reason" to selectedReason,
                                            "extraInformation" to extraInformation,
                                            "timestamp" to System.currentTimeMillis()
                                        )

                                        firestore.collection("late_submissions")
                                            .add(lateData)
                                            .addOnSuccessListener {
                                                showSuccessDialog = true
                                            }
                                            .addOnFailureListener {
                                                // Handle failure
                                            }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = AppColors.DarkGray
                                ),
                                border = BorderStroke(2.dp, AppColors.DarkGray),
                                enabled = selectedLecturer != "Select Lecturer" &&
                                        selectedReason != "Select Reason" &&
                                        extraInformation.isNotBlank()
                            ) {
                                Text("Submit")
                            }
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Image(
                            painter = painterResource(id = R.drawable.late_icon),
                            contentDescription = "Late Icon",
                            modifier = Modifier
                                .size(110.dp)
                                .padding(start = 16.dp)
                        )
                    }
                }
            }
        }

        // Varsity College logo at the bottom
        Image(
            painter = painterResource(id = R.drawable.varsity_college_icon),
            contentDescription = "Varsity College Logo",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
                .height(50.dp)
        )
    }

    if (showSuccessDialog) {
        Dialog(onDismissRequest = { showSuccessDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AppColors.MintGreen)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Your message has been sent successfully",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = AppColors.DarkGray
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showSuccessDialog = false },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = AppColors.DarkGray
                        ),
                        border = BorderStroke(2.dp, AppColors.DarkGray)
                    ) {
                        Text("OK")
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun latePreview() {
    val navController = rememberNavController()
    MaterialTheme {
        Late_Page(navController)
    }
}
