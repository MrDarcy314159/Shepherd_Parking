package za.varsitycollege.shepherd_parking

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShepherdParkingApp()
        }
    }
    // Handle the result from the Google Sign-In intent
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1) {  // Ensure this matches the request code in `signInWithGoogle`
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                account?.let {
                    // You may call a function in your SignUpPage here to handle the sign-in result
                    // or directly handle the sign-in result in this activity
                    handleGoogleSignInResult(it)
                }
            } catch (e: ApiException) {
                Log.w("MainActivity", "Google sign in failed", e)
            }
        }
    }

    // This function handles the sign-in result
    private fun handleGoogleSignInResult(account: GoogleSignInAccount) {
        val auth = FirebaseAuth.getInstance()
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign-in succeeded
                    val user = auth.currentUser
                    Log.d("MainActivity", "signInWithCredential:success. User: ${user?.email}")
                    Toast.makeText(this, "Google Sign-In Successful!", Toast.LENGTH_SHORT).show()
                } else {
                    // If sign-in fails
                    Log.w("MainActivity", "signInWithCredential:failure", task.exception)
                    Toast.makeText(this, "Google Sign-In Failed: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShepherdParkingApp() {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // List of routes where we don't want to show the top bar and drawer
    val routesWithoutTopBarAndDrawer = listOf("login", "newUser", "map_updates")

    // Define light blue color
    val lightBlue = Color(0xFFE3F2FD)  // You can adjust this hex code as needed

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            if (currentRoute !in routesWithoutTopBarAndDrawer) {
                ModalDrawerSheet {
                    Box(
                        modifier = Modifier
                            .background(AppColors.MintGreen)
                            .fillMaxWidth()
                            .height(150.dp)
                            .padding(16.dp)
                    ) {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            // Icon at the top of the drawer
                            Icon(
                                painter = painterResource(id = R.drawable.sheep), // Ensure this points to the correct drawable
                                contentDescription = "App Icon",
                                modifier = Modifier.size(80.dp), // Adjust size as needed
                                tint = Color.Unspecified // Make sure tint does not affect the drawable
                            )
                            Spacer(modifier = Modifier.height(8.dp)) // Space between icon and text
                            Text(
                                text = "Shepherd Parking",
                                color = Color.Black, // Adjust text color to contrast with background
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("Home") },
                        selected = currentRoute == "home",
                        onClick = {
                            navController.navigate("home")
                            scope.launch { drawerState.close() }
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Settings") },
                        selected = currentRoute == "settings",
                        onClick = {
                            navController.navigate("settings")
                            scope.launch { drawerState.close() }
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.CheckCircle, contentDescription = null) },
                        label = { Text("Check In") },
                        selected = currentRoute == "check_in",
                        onClick = {
                            navController.navigate("check_in")
                            scope.launch { drawerState.close() }
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Share, contentDescription = null) },
                        label = { Text("Traffic Feedback") },
                        selected = currentRoute == "traffic_feedback",
                        onClick = {
                            navController.navigate("traffic_feedback")
                            scope.launch { drawerState.close() }
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Email, contentDescription = null) },
                        label = { Text("Late") },
                        selected = currentRoute == "late",
                        onClick = {
                            navController.navigate("late")
                            scope.launch { drawerState.close() }
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                        label = { Text("Analytics") },
                        selected = currentRoute == "analytics",
                        onClick = {
                            navController.navigate("analytics")
                            scope.launch { drawerState.close() }
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                        label = { Text("Map Updates") },
                        selected = currentRoute == "map_updates",
                        onClick = {
                            navController.navigate("map_updates")
                            scope.launch { drawerState.close() }
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Face, contentDescription = null) },
                        label = { Text("Guard House") },
                        selected = false,
                        onClick = {
                            navController.navigate("guard_house") {
                                popUpTo(0)
                            }
                            scope.launch { drawerState.close() }
                        }
                    )
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Lock, contentDescription = null) },
                        label = { Text("Logout") },
                        selected = false,
                        onClick = {
                            navController.navigate("signUp") {
                                popUpTo(0)
                            }
                            scope.launch { drawerState.close() }
                        }
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                if (currentRoute !in routesWithoutTopBarAndDrawer) {
                    TopAppBar(
                        title = { Text("Menu") },
                        navigationIcon = {
                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, contentDescription = "Menu")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = lightBlue,  // Set to light blue
                            titleContentColor = Color.Black,
                            navigationIconContentColor = Color.Black
                        )
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AppColors.MintGreen)
                    .padding(innerPadding)
            ) {
                NavHost(navController = navController, startDestination = "signUp") {
                    composable("signUp") { SignUpPage(navController) }
                    composable("login") { LoginPage(navController) }
                    composable("newUser") { NewUserPage(navController) }
                    composable("home") { HomePage(navController) }
                    composable("settings") { SettingsPage(navController) }
                    composable("check_in") { CheckInPage(navController) }
                    composable("traffic_feedback") { TrafficFeedbackPage(navController) }
                    composable("late") { Late_Page(navController) }
                    composable("analytics") { AnalyticsPage(navController) }
                    composable("map_updates") { MapUpdatesPage(navController) }
                    composable("guard_house") { GuardHousePage() }
                    composable("lecturer_details") { LecturerDetailsPage() }
                }
            }
        }
    }
}