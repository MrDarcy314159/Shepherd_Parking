package za.varsitycollege.shepherd_parking

import android.content.Context

class UserManager(context: Context) {
    private val sharedPreferences = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

    fun saveUser(email: String, password: String, name: String, surname: String, studentNumber: String) {
        with(sharedPreferences.edit()) {
            putString("${email}_password", password)
            putString("${email}_name", name)
            putString("${email}_surname", surname)
            putString("${email}_studentNumber", studentNumber)
            apply()
        }
    }

    fun getUser(email: String): User? {
        val password = sharedPreferences.getString("${email}_password", null) ?: return null
        val name = sharedPreferences.getString("${email}_name", "")
        val surname = sharedPreferences.getString("${email}_surname", "")
        val studentNumber = sharedPreferences.getString("${email}_studentNumber", "")
        return User(email, password, name!!, surname!!, studentNumber!!)
    }

    fun isValidLogin(email: String, password: String): Boolean {
        val user = getUser(email)
        return user != null && user.password == password
    }
}

data class User(
    val email: String,
    val password: String,
    val name: String,
    val surname: String,
    val studentNumber: String
)