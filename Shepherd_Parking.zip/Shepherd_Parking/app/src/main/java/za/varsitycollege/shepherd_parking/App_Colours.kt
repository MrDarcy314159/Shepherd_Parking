package za.varsitycollege.shepherd_parking

import androidx.compose.ui.graphics.Color

object AppColors {
    val MintGreen = Color(0xFFA8E2D0)
    val DarkGray = Color(0xFF333333)
    // Add any other custom colors here
}
